<?php

function number($x){
    $str = str_replace(',','.',$x);
    return intval($str);
}

$a = floatval(6.0);
$b = floatval(0.20);
$c = floatval(0.60);
$e = floatval(0.70);

if (isset($_POST['a'])){
    $a = number($_POST['a']);
}
if (isset($_POST['b'])){
    $b = number($_POST['b']);
}
if (isset($_POST['c'])){
    $c = number($_POST['c']);
}
if (isset($_POST['e'])){
    $e = number($_POST['e']);
}

$l = 1;
$h = 0.1;
$tau = $h / $a;
$gamma = $a * $tau / $h;
$gamma = $gamma * $gamma;
$I = 10;
$J = 10;
$y = array();

// Boshlang'ich shartlar
for ($i = 0; $i <= $I; $i++) {
    $y[$i][0] = ux0($i * $h);
}

// Birinchi qatlam
for ($i = 0; $i <= $I; $i++) {
    $y[$i][1] = ux0($i * $h) + $tau * ux_0($i * $h);
}

// Chegaraviy qatlam
for ($j = 0; $j <= $J; $j++) {
    $y[0][$j] = 0;
    $y[$I][$j] = 0;
}

// Qoldiqlar uchun hisoblash
for ($j = 1; $j <= $J; $j++) {
    for ($i = 1; $i < $I; $i++) {
        $y[$i][$j + 1] = -1 * $y[$i][$j - 1] + $gamma * ($y[$i - 1][$j] + $y[$i + 1][$j]) + 2 * (1 - $gamma) * $y[$i][$j];
    }
}
// f(x) funksiyonlari
function ux0($x)
{
    global $a, $b, $c;
    if ($x >= $b && $x <= ($b + $c) / 2) {
        $f = 2 * $a * ($x - $b) / ($c - $b);
    } else if ($x >= ($b + $c) / 2 && $x <= $c) {
        $f = 2 * $a * ($c - $x) / ($c - $b);
    } else {
        $f = 0;
    }
    return $f;
}

function ux_0($x)
{
    global $a, $b, $e;
    if ($x >= 0 && $x <= $b) {
        $f = $a * $x / $b;
    } else if ($x >= $b && $x <= $e) {
        $f = $a;
    } else {
        $f = ($a - 1) * $x / ($e - 1);
    }
    return $f;
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>4-Labaratoriya ishi</title>
    <link rel="stylesheet" href="../css/style.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">

</head>
<body>
    <marquee> <h2>Hisoblash usullari topshiriq</h2> </marquee>
    <hr><br>
    <div class="div">
        <form action="" method="POST">
            <input type="text" name="a" placeholder="a" required>
            <input type="text" name="b" placeholder="b" required>
            <input type="text" name="c" placeholder="c" required>
            <input type="text" name="e" placeholder="e" required>
            <input type="submit" name="" value="hisoblash">
        </form>
    </div>
    <table class="table container">
        <thead>
        <tr>
            <th scope="col">i</th>
            <th scope="col">x<sub>i</sub></th>
            <th>Y</th>
        </tr>
        </thead>
        <tbody class="table-group-divider">
            <?php
                for ($j = 0;$j <= $J;$j ++){
                    ?>
                        <tr>
                            <td><?=$j?></td>
                            <td><?=($j * $h)?></td>
                    <?
                     for ($i = 0; $i <= $I; $i++) {
                        ?>
                            <td><?=$y[$i][$j]?></td>
                         <?
                     }
                     ?>
                        </tr>
                    <?
                }
            ?>
        </tbody>
    </table>
</body>
</html>
